package work02;

import java.io.IOException;

public class ControlTest { 
	
    public static void main(String[] args) throws IOException {
    	char choice;
    	do{
    		System.out.println("Help on:");
            System.out.println("1. if:");
            System.out.println("2. switch");
            System.out.println("3. while");
            System.out.println("4. for");
            System.out.println("5. do-while");
            System.out.println("choose one: ");

    		choice = (char)System.in.read();
//    		예외 선언 추가
    	} while(choice<'1' | choice>'5');
    	
    	System.out.println("\n");
//    	사용자 선택 후 하난 띄어서 출력
    	
    	switch(choice) {
    	case '1':
    		System.out.println("if 문법...");
    		break;
    	}
    	char ch;
    	int spaces = 0;
    	System.out.println("Enter a period to stop.");
    	do {
    		ch = (char) System.in.read();
    		if(ch==' ');
    		spaces++;
    	} while (ch != '.');
    	
    	System.out.println("공백의 갯수: "+ spaces);
    }
  
}