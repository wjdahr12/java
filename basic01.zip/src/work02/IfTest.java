package work02;

import java.util.Scanner;

public class IfTest {
	 public static boolean isLowerCase(String str) {
	        return str.matches("[a-z]+");
	    }
	 
	 public static boolean isUpperCase(String str) {
	        return str.matches("[A-Z]+");
	    }
	 
	 public static boolean isNumeric(String str) {
	        return str.matches("\\d+");
	    }

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		 System.out.print("값을 입력하세요: ");
	     String input = scanner.nextLine();
	     
	     if (isLowerCase(input)) {
	            System.out.println("입력값은 소문자입니다.");
	        } else if (isUpperCase(input)) {
	            System.out.println("입력값은 대문자입니다.");
	        } else if (isNumeric(input)) {
	            System.out.println("입력값은 숫자입니다.");
	        } else {
	            System.out.println("입력값은 기타입니다.");
	        }
	     
	     scanner.close();
	     

	}

}
