package work01;

//자료형 변수명 = 값;
public class VarTest {

	public static void main(String[] args) {
//		변수의 크기 확인
		byte b1 = 127;
		System.out.println(b1);

//		문자저장
		char c1 = 'a';
		System.out.println(c1);
		
		char c2 = '가';
		System.out.println(c2);
		
//		stack
		int a = 10;
		{
			int b = 20;
			{
				int c = 30;
				System.out.println("c:" + c);
//				System.out.println("b:" + b);
//				System.out.println("a:" + a);
			}
			System.out.println("b:" + b);
		}
		System.out.println("a:" + a);
		
	}

}