package work04;

public class ArrayTest3 {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁		
		int[] first = {1, 78, 65, 89};
		int[] second = new int[4];
		int[] third = new int[4];
		
//		2차원배열 3행4열로 만듬
		int[][] arr = new int[3][4];

		int [][] arr2 = {
				{1, 78, 65, 89},
				{2, 78, 65, 89},
				{3, 78, 65, 89}
		};
		System.out.println(first[0]);
		System.out.println(arr2[0][0]);
		
//		불규칙 배열
		char[][] name = new char[2][6];
		name[0][0] = 'T';
		name[0][1] = 'o';
		name[0][2] = 'm';
		
		name[1][0] = 'M';
		name[1][1] = 'a';
		name[1][2] = 'r';
		name[1][3] = 'r';
		name[1][4] = 'y';
//		불규칙 배열: 그때 그때 필요한만큼만 열을만드는 작업, 공간 아끼기
		char [][] name2 = new char [2][];
		name2[0] = new char[3];
		name2[1] = new char [5];
		
//		공항 셔틀의 탑승객의 수를 저장하는 프로그램 만들기
//		(셔틀이 주중에는 10회 운행하고, 주말에는 2번 운행함)
		int shuttle[][] = new int[7][];
		for(int i=0; i<5; i++) {
			shuttle[i] = new int[10];
		}
		
		shuttle[5] = new int[2];
		shuttle[6] = new int[2];
//		가짜 데이터 입력
		for(int i=0; i<5; i++) {
			for(int j=0; j<10; j++) {
				shuttle[i][j] = i + j + 10;
			}
		}
		
		for(int i=5; i<7; i++) {
			for(int j=0; j<2; j++) {
				shuttle[i][j] = i + j + 10;
			}
		}
        // 결과 출력
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < shuttle[i].length; j++) {
                System.out.print(shuttle[i][j] + "\t");
            }
            System.out.println();
        }
		
	}

}
