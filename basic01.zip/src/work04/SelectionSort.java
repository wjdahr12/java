package work04;
//선택정렬로 만들기
public class SelectionSort {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		int[] data = {
				2, 9, 10, 3, 7, 15, 5
		};
		for (int i=0; i<data.length; i++) 
			System.out.println(data[i] + "\t");
		
		System.out.println("\n\n버블정렬 후...");

	}

}
