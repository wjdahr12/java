package work04;

import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
//		Scanner 자바의 표준 입력을 받아들일 수 있는 클래스
//		System.in 키보드 인식을 받아들임
		
		System.out.println("이름 입력: ");
		String name = scan.next();
//		scan.nextLine(); 공백도 받아들이는 코드 
		System.out.println("당신의 이름은" + " " + name + "이다.");
		
		System.out.println("나이 입력: ");
		int age = scan.nextInt();
//		숫자로 바꿔주는 함수
		System.out.println("당신의 나이는" + " " + age + "이다.");
		
		System.out.println("점수 입력: ");
		double point = scan.nextDouble();
//		실수형으로 바꿔주는 함수
		System.out.println("당신의 점수는" + " " + point + "이다.");

	}

}
