package work04;

public class Encode예제 {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		String msg = "x맨은 홍길동이다.";
		String key = "axdk?!";
		
		// 메시지를 암호화한 값
		
		
		
		// 암호화된 메시지를 복호화

	}

}
