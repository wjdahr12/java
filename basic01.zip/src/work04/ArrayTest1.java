package work04;

public class ArrayTest1 {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		int no=1, kor=78, eng=65, mat=89;
		
		int[] first = new int[4];
		first[0] = 1;
		first[1] = 78;
		first[2] = 65;
		first[3] = 89;
		
		for(int i=0; i<4; i++) {
			System.out.println(first[i]);
		}
		
		int[] second = {1, 78, 65, 89};
		for(int s : second) {
			System.out.println(s);
		}
		
//		int[] = third;
//		third = {1,2,3,4}; 불가

  }

}