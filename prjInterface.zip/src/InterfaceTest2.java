//interface Interf1 {
//	int a = 1;
////	inter1이 이미 같은 패키지에 만들어져 있어서 interf1으로 고침
//}
//
//interface Interf2 {
//	int b = 2;
//}
//
//interface Interf3 {
//	int c = 3;
//}
//
//public class InterfaceTest2 implements Interf1, Interf2, Interf3 {
//
//	public static void main(String[] args) {
//		// TODO 인터페이스 다중 상속
//		System.out.println(Interf1.a+", " + Interf2.b+", "+Interf3.c);
//
//	}
//
//}

//	인터페이스들끼리도 상속 가능;
//interface Interf1 {
//	int a = 1;
////	inter1이 이미 같은 패키지에 만들어져 있어서 interf1으로 고침
//}
//
//interface Interf2 extends Interf1 {
//	int b = 2;
//}
//
//interface Interf3 extends Interf2 {
//	int c = 3;
//}
//
//public class InterfaceTest2 implements Interf3 {
//
//	public static void main(String[] args) {
//		// TODO 인터페이스 다중 상속
//		System.out.println(Interf1.a+", " + Interf2.b+", "+Interf3.c);
//
//	}
//
//}


interface Interf1 {
	int a = 1;
//	inter1이 이미 같은 패키지에 만들어져 있어서 interf1으로 고침
}

interface Interf2 {
	int b = 2;
}

interface Interf3 extends Interf1, Interf2 {
	int c = 3;
}

public class InterfaceTest2 implements Interf3 {

	public static void main(String[] args) {
		// TODO 인터페이스 다중 상속
		System.out.println(a+", " + b+", "+c);
//		interface는 객체생성으로 안해도 바로 Interf1.a로 호환가능

	}

}