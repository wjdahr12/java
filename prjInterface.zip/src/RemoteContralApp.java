//power interface 정읜


public class RemoteContralApp {

	public static void main(String[] args) {
		

	}

}
