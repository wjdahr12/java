//interface Inter1 {
//	int a = 1;
////	기본적으로 static의 특성을 가짐; final까지도 가짐; 즉, 고유한 값이라 변경할 수 없음
////	 즉, public static final이 앞에 생략되어 있음
////	interface는 접근을 제한하는 private, protected 등을 사용할 수 없음; 무조건 많이 접근하도록 만들어졌기 때문
//	void Inter1Method();
////	interface라서 abstract를 안붙여도 됨; class였으면 추상클래스, 추상메소드 문법 abstract 사용;
//}

 abstract class Inter1 {
	 static int a = 1;
//	static으로 변수 호환되게 해야함
	abstract void Inter1Method();
}

public class InterfaceTest1 extends Inter1 {
//	public class InterfaceTest1 extends Inter1
	public  void Inter1Method() {
		System.out.println("overriding 됨");
	}

	public static void main(String[] args) {
		// TODO 인터페이스 기본 문법
		System.out.println(a);
		System.out.println(Inter1.a);
//		Inter1.a = 10; interface에 있는 변수라 수정 불가;
		
		

	}

}
