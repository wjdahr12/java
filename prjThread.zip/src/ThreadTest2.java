/*
public class ThreadTest2 implements Runnable {

	long add = 0;
	String name;
	
//	public ThreadTest2(long a, String n) {
//		super();
//	}

	@Override
	// 부모가 물려준건 똑같이 써야함
	public void run() {
//		run메소드가 쓰레드의 동작 기능을 구현하는 메소드임
		System.out.println("자식 스레드 시작");
		long all = 0;
		
		for(int i=0; i<=add; i++) {	
			try {
				Thread.sleep(5);
//				0.2초면 거의 동시작업
//				Runnabled에선 Thread.을 붙여줘야 호환됨
			} catch (InterruptedException e) {
				// TODO 자동 생성된 catch 블록
				e.printStackTrace();
			}
//			throws 사용불가; Override기능을 사용했기 때문
			all += i;
			System.out.println(name + ":" + all);
		}
		
		System.out.println("자식 스레드 종료");
		
		
	}
	
//	main() -> 부모 쓰레드
	public static void main(String[] args) {
		// TODO Runnable 인터페이스를 통해 스레드를 만드는 방법
		System.out.println("메인 스레드 시작");
		
		ThreadTest1 t1 = new ThreadTest1(5, "첫번째 쓰레드");
//		ThreadTest1 t2 = new ThreadTest1(5, "첫번째 쓰레드");

		
		Thread tt1 = new Thread(t1);
//		Thread tt2 = new Thread(t2);
//		매개체를 한번더 만들어줘야 Runnable 작동

		
		tt1.start();
//		tt2.start();
//		start(); 메소드 Thread를 구현하기 위해 run();메소드를 호출해줄 수 있는 메소드;
//		직접 부르진 못하고 CPU(가상머신)에서 대신 호출해줌
		
		for(int i =0; i<10; i++) {
			System.out.println(".");
		}
		System.out.println("메인 스레드 종료");

	}
	
	
}
*/

class ThreadDemo implements Runnable {
	String name;
	Thread t;

	public ThreadDemo(String name) {
		// TODO 자동 생성된 생성자 스텁
		this.name = name;
		
		// 스레드 객체 생성
        t = new Thread(this);
        
     // 스레드 시작
        t.start();
       
		
	}

	@Override
	public void run() {
		// TODO 자동 생성된 메소드 스텁
		for (int i=0; i<5; i++) {
			System.out.println(name + ":" + i);
		}
	}
	
}

public class ThreadTest2 {
	
	public static void main(String[] args) {
		ThreadDemo d1 = new ThreadDemo("Thread1");
		ThreadDemo d2 = new ThreadDemo("Thread2");
		ThreadDemo d3 = new ThreadDemo("Thread3");
		
		
        
     
		
	}
}























