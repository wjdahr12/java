import java.util.Stack;

class AutoMachine {
	Stack store = new Stack();
	
	synchronized void putDrink(String drink) {
		store.push(drink);
		notify();
	}
	
	synchronized String getDrink() {
		while(store.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		return store.pop().toString();
	}
}

class Producer extends Thread{
	private AutoMachine auto;
	
	public Producer(AutoMachine auto) {
		this.auto = auto;
	}
	
	@Override
	public void run() {
		for(int i=0; i<10; i++) {
			System.out.println(getName() + " : 음료수 No." + i + " 채워넣음");
			auto.putDrink("음료수 No." + i);
			
			try {
				sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class Consumer extends Thread {
	private AutoMachine auto;
	
	public Consumer(AutoMachine auto) {
		this.auto = auto;
	}
	
	@Override
	public void run() {
		for(int i=0; i<10; i++) {
			System.out.println(getName() + " : 음료수 No." + i + " 꺼내먹음");
			auto.getDrink();
			
			try {
				sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

public class ThreadTest6 {
	public static void main(String[] args) {
		// TODO wait, notify
		
		AutoMachine auto = new AutoMachine();
		
		Producer hong = new Producer(auto);
		Consumer kim = new Consumer(auto);
		
		hong.start();
		kim.start();
	}
}


