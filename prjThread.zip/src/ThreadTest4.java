// alive 사용법	
/*
class FinishDemo implements Runnable{
	long add = 0;
	String name;
	
	FinishDemo(long a, String name){
	this.name = name;
	add = a;
	}
	
	@Override
	public void run(){
	System.out.println(name + " 자식 스레드 시작");
	long all = 0;
	
	for(int i=0; i<=add; i++) {
	try {
	Thread.sleep(100);
	} catch (InterruptedException e) {
	e.printStackTrace();
	}
	
	all += i;
	System.out.println(name + ":" + all);
	}
	
	System.out.println(name + " 자식 스레드 종료");
	}
	}
	
	public class ThreadTest4 {
	public static void main(String[] args) {
	// TODO 스레드의 종료 시점
	System.out.println("메인 스레드 시작");
	
	FinishDemo t1 = new FinishDemo(10, "first");
	FinishDemo t2 = new FinishDemo(10, "second");
	
	Thread tt1 = new Thread(t1);
	Thread tt2 = new Thread(t2);
	
	tt1.start();
	tt2.start();
	
	for(; ;) {
		if(!tt1.isAlive() && !tt2.isAlive()) {
			break;
		}
		
	try {
		Thread.sleep(100);
	} catch (InterruptedException e) {
	e.printStackTrace();
	}
	
	System.out.print(".");
	
	}
	
	System.out.println("메인 스레드 종료");
	}
	}
*/

class FinishDemo implements Runnable{
	long add = 0;
	String name;
	
	FinishDemo(long a, String name){
	this.name = name;
	this.add = a;
	}
	
	@Override
	public void run(){
	System.out.println(name + " 자식 스레드 시작");
	long all = 0;
	
	for(int i=0; i<=add; i++) {
	try {
	Thread.sleep(100);
	} catch (InterruptedException e) {
	e.printStackTrace();
	}
	
	all += i;
	System.out.println(name + ":" + all);
	}
	
	System.out.println(name + " 자식 스레드 종료");
	}
	}
	
	public class ThreadTest4 {
	public static void main(String[] args) throws InterruptedException {
	// TODO 스레드의 종료 시점
	System.out.println("메인 스레드 시작");
	
	FinishDemo t1 = new FinishDemo(10, "first");
	FinishDemo t2 = new FinishDemo(10, "second");
	
	Thread tt1 = new Thread(t1);
	Thread tt2 = new Thread(t2);
	
	tt1.start();
	tt2.start();
	
	for(int i=0; i<10; i++) {
	try {
		Thread.sleep(100);
	} catch (InterruptedException e) {
	e.printStackTrace();
	}
	
	System.out.print(".");
	
	}
	tt1.join();
	tt2.join();
	
	System.out.println("메인 스레드 종료");
	}
}