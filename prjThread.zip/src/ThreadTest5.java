class Toilet {
	public synchronized void openDoor(String name) {
		System.out.println(name + "입장");
		
		for(int i=0; i<10000; i++) {
			if(i==5000) {
				System.out.println(name + " : 끄응~~" );
			}
		}
		System.out.println(name + "퇴장");
		
	}
}

class Family extends Thread {
	Toilet toilet;
	String who;
	
	public Family(Toilet toilet, String who) {
		super();
		this.toilet = toilet;
		this.who = who;
	}
	
	@Override
	public void run() {
		toilet.openDoor(who);
	}
}

public class ThreadTest5 {

	public static void main(String[] args) {
		// TODO 동기화 처리하기
		Toilet t = new Toilet();
		
		Family father = new Family(t, "아버지");
		Family mother = new Family(t, "어머니");
		Family brother = new Family(t, "형");
		Family sister = new Family(t, "누나");
		Family me = new Family(t, "나");
		
		father.start();
		mother.start();
		brother.start();
		sister.start();
		me.start();

	}

}
