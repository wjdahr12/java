/*
 * 하나의 쓰레드 !!
public class ThreadTest1 {
	long add = 0;
	
	ThreadTest1(long a) {
		add = a;
	}

	public static void main(String[] args) {
		ThreadTest1 t = new ThreadTest1(100);
		long all = 0;
		
		for(int i=0; i<=t.add; i++) {			
			all += i;
			System.out.println(all);
		}

	}

}
*/

public class ThreadTest1 extends Thread {
//	java.lang에 있는 Thread라서 그냥 상속가능
	long add = 0;
	String name;

	
	public ThreadTest1(long a, String n) {
		this.add = a;
		this.name = n;
	}

	@Override
	// 부모가 물려준건 똑같이 써야함
	public void run() {
//		run메소드가 쓰레드의 동작 기능을 구현하는 메소드임
		
		System.out.println("자식 스레드 시작");
		long all = 0;
		
		for(int i=0; i<=add; i++) {	
			try {
				sleep(100);
//				0.2초면 거의 동시작업
			} catch (InterruptedException e) {
				// TODO 자동 생성된 catch 블록
				e.printStackTrace();
			}
//			throws 사용불가; Override기능을 사용했기 때문
			all += i;
			System.out.println(name + ":" + all);
		}
		
		System.out.println("자식 스레드 종료");
		
		
	}
	
//	main() -> 부모 쓰레드
	public static void main(String[] args) {
		// TODO Thread클래스를 상속받아 스레드를 만드는 방법
		System.out.println("메인 스레드 시작");
		
		ThreadTest1 t1 = new ThreadTest1(5, "첫번째 쓰레드"); // 자식 쓰레드
//		클래스 자체를 쓰레드로부터 상속받으면 만들어진 객체 자체도 다쓰레드가 됨

		
		t1.start();
//		start(); 메소드 Thread를 구현하기 위해 run();메소드를 호출해줄 수 있는 메소드;
//		직접 부르진 못하고 CPU(가상머신)에서 대신 호출해줌
		
		for(int i =0; i<10; i++) {
			System.out.println(".");
		}
		System.out.println("메인 스레드 종료");

	}
	
	
}
	
////	main() -> 부모 쓰레드
//	public static void main(String[] args) {
//		ThreadTest1 t1 = new ThreadTest1(5, "첫번째 쓰레드"); // 자식 쓰레드
//		ThreadTest1 t2 = new ThreadTest1(5, "두번째 쓰레드"); // 자식 쓰레드
////		클래스 자체를 쓰레드로부터 상속받으면 만들어진 객체 자체도 다쓰레드가 됨
////		메인 메소드까지 합쳐서 현재 총 3개의 쓰레드
//		
//		t1.start();
//		t2.start();
////		start(); 메소드 Thread를 구현하기 위해 run();메소드를 호출해줄 수 있는 메소드;
////		직접 부르진 못하고 CPU(가상머신)에서 대신 호출해줌
//	
//
//	}

