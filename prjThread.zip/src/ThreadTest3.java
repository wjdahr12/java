/*
class StopDemo implements Runnable {

	@Override
	public void run() {
		// TODO 자동 생성된 메소드 스텁
		try {
			while (true) {
				System.out.println("Thread is alive ...");
			
				Thread.sleep(500);
				}
			} catch (InterruptedException e) {
				// TODO 자동 생성된 catch 블록
				e.printStackTrace();
			}
			finally {
				System.out.println("Thread is dead ...");
			}
		}
	}
	



public class ThreadTest3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Thread의 강제 종료
		StopDemo demo = new StopDemo();
		Thread t = new Thread(demo);
		t.start();
		
		Thread.sleep(5000);
		
		t.stop();

	}

}
*/

class StopDemo implements Runnable {
	private boolean stopped = false;
	
	void off () {
		stopped = true;
	}

	@Override
	public void run() {
		// TODO 자동 생성된 메소드 스텁
		try {
			while (!stopped) {
				System.out.println("Thread is alive ...");
			
				Thread.sleep(500);
				}
			} catch (InterruptedException e) {
				// TODO 자동 생성된 catch 블록
				e.printStackTrace();
			}
			finally {
				System.out.println("Thread is dead ...");
			}
		}
	}
	



public class ThreadTest3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Thread의 강제 종료
		StopDemo demo = new StopDemo();
		Thread t = new Thread(demo);
		t.start();
		
		Thread.sleep(5000);
		
		demo.off();

	}

}
