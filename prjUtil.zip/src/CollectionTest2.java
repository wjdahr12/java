import java.util.ArrayList;

public class CollectionTest2 {

	public static void main(String[] args) {
		// TODO List 계열의 클래스들
		
		ArrayList list = new ArrayList();
		list.add("carrie");
		list.add("kairo");
		list.add("kabbin");
		list.add("kairo");
		list.add("terry");
		
		System.out.println("데이터 개수 : " + list.size());
		System.out.println(list);
		
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		// 검색기능
		if(list.contains("kairo")) {
			System.out.println("찾았다.");
			System.out.println(list.indexOf("kairo")+ "번째에 있다.");
		} else {
			System.out.println("못찾았다.");
		}
		
		list.add(2,100);
//		100이라는 숫자가 3번째 위치에 추가됨
		System.out.println(list);
		
		list.remove(3);
//		4번째 위치 데이터 지워버리기
		System.out.println(list);

	}

}
