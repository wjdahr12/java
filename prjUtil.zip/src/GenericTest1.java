import java.util.Vector;

public class GenericTest1 {

	public static void main(String[] args) {
		// TODO 타입을 미리 체크
		Vector <String> v = new Vector<String>();
//		객체 타입을 사용해야해서 wrapper클래스 필요
//		<String> 문자열만 저장하겠다는 뜻;
		v.add("hello");
		v.add("world");
		v.add("홍길동");
		//...
//		v.add(100);
		
		String str = null;
		for(int i=0; i<v.size(); i++) {
			str = (String) v.get(i);
			System.out.println(str);
		}
		
//		for(String str : v)
//			System.out.println(str);

	}

}
