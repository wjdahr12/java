import java.util.Random;

public class RandomTest {

	public static void main(String[] args) {
		// TODO 난수 처리
		Random rnd = new Random();
		
		System.out.println(rnd.nextInt());
		System.out.println(rnd.nextInt(5)); // 0부터 4까지 5개의 숫자중에서 하나를 뽑아내는 것
		
		// (쵀댓값 - 최소값 +1) + 최소값
		// 11~ 25
		System.out.println(rnd.nextInt((25-11+1)+11));
		
		// 가위 바위 보 게임
		// 로또 추출기

	}

}
