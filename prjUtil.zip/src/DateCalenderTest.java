
import java.util.Calendar;
import java.util.Date;

public class DateCalenderTest {

	public static void main(String[] args) {
		// TODO Date class와 Calendar class의 차이점
		
//		Date클래스
		 Date date = new Date();
		 System.out.println(date);
		 System.out.println(new Date());
		 System.out.println(new Date().toString()); //toString()생략됨; 이걸로 다객체 생성
		 
		 DateCalenderTest test = new DateCalenderTest();
		 System.out.println(test.toString()); //그냥 test랑 같은 말임
		 
		// 주로 현재 날짜를 구할 때 사용
		 
		 
//		 Calendar클래스
		 Calendar cal = Calendar.getInstance();
//		 singleton문법 단하나의 객체만 생성; 어차피 날짜는 단 하나만 있으면 되니까
		 System.out.println(cal);
		 System.out.println(cal.get(Calendar.YEAR));
		 System.out.println(cal.get(Calendar.MONTH)+1); // 가로로 묶고 그뒤에 +1해야 추가됨
		 // 컴퓨터 언어 0부터 시작하기에 8월이 나와서 +1을 붙이는 것임
		 System.out.println(cal.get(Calendar.DATE));
		 System.out.println(cal.get(Calendar.HOUR));
		 

	}

}
