import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class CollectionTest1 {

	public static void main(String[] args) {
		// TODO Set계열의 클래스들
		HashSet set = new HashSet();
		
		set.add("carrie");
		set.add("kabbin");
		set.add("kairo");
		set.add("kairo");
		set.add("kariss");
		
		System.out.println("데이터 개수: " + set.size());
		System.out.println(set);
//		hashset이라는 객체타입; 꺼내쓰는 것이아닌 저장의 목적
		
		Iterator it = set.iterator(); // Iterator 객체 얻기
		while(it.hasNext()) {
			System.out.println(it.next()); // 다음 요소 얻기
		}
//		Iterator로 꺼내오기 가능
//		컬렉션 내의 데이터를 순서대로 접근
//		컬렉션의 내부구조를 알필요 없이 순회 가능
//		데이터 추가, 수정, 삭제할 때에도 안전하게 순회 가능
		
		
		TreeSet tree = new TreeSet();
		
		tree.add("juliet");
		tree.add("terry");
		tree.add("kabbin");
		tree.add("terry");
		tree.add("carrie");
		
		System.out.println("데이터 개수 : "+ tree.size());
		System.out.println(tree);
		

	}

}
