import java.util.StringTokenizer;

public class StringTokenizerTest {

	public static void main(String[] args) {
		// TODO 문자열 분리
		String data = "홍길동, 임꺽정, 신돌석, 강감찬";
		
		String[] names =  data.split(",");
		for(String name: names) {
			System.out.println(name.trim());
//			trim(); 공백제거 정렬시켜줌
		}
		
		StringTokenizer token = new StringTokenizer(data, ",");
//		StringTokenizer 유틸 클래스 불러옴
		System.out.println(token.countTokens());
//		,을 기준으로 카운트 매기기
		
//		System.out.println(token.nextToken());
////		기본적으로 공백을 구분자로 사용하지만 지금은,을 구분자로 사용
////		nextToken();가 호출될대마다 다음 구분자까지의 문자열 추출
//		System.out.println(token.nextToken().trim());
//		System.out.println(token.nextToken().trim());
//		System.out.println(token.nextToken().trim());
		
		while(token.hasMoreTokens()) {
			System.out.println(token.nextToken().trim());
//			hasMoreTokens();아직 처리되지 않은 토큰이 있는지 확인하고, nextToken()로 다음토큰 반환
		}
		System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
		
		String data2 = "홍길동+ 임꺽정* 신돌석? 권율~ 강감찬";
		token = new StringTokenizer(data2, "+*?~");
//		split();은 요거 안됨; 정규표현식만 사용 가능
		
		while(token.hasMoreTokens()) {
			System.out.println(token.nextToken().trim());

		}
		
		String data3 = "JavaTM 언어사양 제2판: James Gosling, Bill Join,"+
		"Gilad Bracha:무라카미 마사키: 피어슨 에듀케이션:2000:5500";
		
		/*
		 * 책 제목: avaTM 언어사양 제2판
		 * 저자: James Gosling
		 * 		Bill Join
		 * 		Gilad Bracha
		 * 역자: 무라카미 마사키
		 * 출판사: 피어슨 에듀케이션
		 * 출판년도: 2000
		 * 가격: 5500
		 * 
		 */
		
		StringTokenizer strtoken = new StringTokenizer(data3, ":");
		String[] obj = {
				"책 제목", "저자", "역자", "출판사", "출판년도", "가격"
				};
		
		for (int i = 0; i < obj.length; i++) {
			if (i == 1 || i == 2) { // 저자, 역자는 둘 이상일 가능성 있음
				System.out.print(obj[i] + " : ");
				StringTokenizer Token = new StringTokenizer(strtoken.nextToken(), ",");
				while(Token.hasMoreTokens()) {
					System.out.println("\t" + Token.nextToken().trim());
				}
			} else {
				System.out.println(obj[i] + " : " + strtoken.nextToken().trim());
			}
		}
		

	}

}
