class GenericDomo<T> {
	T value;
//	T란 실행중에 타입을 정하겠다는 의미
//	정수형, 실수형, 문자형 다 사용 가능
//	이런 이유들로 Generic사용
	
	public GenericDomo(T val) {
		value = val;
	}
	
	T getValue() {
		return value;
	}
}


public class GenericTest2 {

	public static void main(String[] args) {
		// TODO Template 기능
		
		GenericDomo<Integer> demo1 = new GenericDomo<Integer>(10);
		System.out.println(demo1.getValue());
		
		GenericDomo<Double> demo2 = new GenericDomo<Double>(3.14);
		System.out.println(demo2.getValue());
		
		GenericDomo<String> demo3 = new GenericDomo<String>("이것은 제너릭");
		System.out.println(demo3.getValue());

	}

}
