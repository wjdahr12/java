import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class CollectionTest3 {

	public static void main(String[] args) {
		// TODO Map 계열의 클래스들
		HashMap map = new HashMap();
		map.put("k1", "홍길동");
		map.put("k2", "임꺽정");
		map.put("k3", "유비");
		map.put("k4", "관우");
		map.put("k5", "장비");
//		map.put("k1", "장비"); 이렇게 되면 ㅈ대는거임; 에러도 안뜨고 k1값이 장비로 바껴버림;
		
		System.out.println("데이터 개수 : " + map.size());
		System.out.println(map);
		
		System.out.println(map.get("k2"));
//		get(); get에는 key가 들어감;
//		결과값: k2 값이 출력;
		
		Set set = map.keySet();
		Iterator it = set.iterator(); // Iterator 객체 얻기
		while(it.hasNext()) {
			String key = (String) it.next();
			System.out.println(map.get(key)); // 다음 요소 얻기
		}
//		맵 데이터를 꺼내오기 위해 Iterator를 사용해야해서 set으로 형식 변환
		
//		for(int i=0; i<map.size(); i++) {
//			System.out.println(map.get(i));
//		} map은 사용불가, list만 가능

	}

}
