
public class CurrentTimeTest {

	public static void main(String[] args) {
		// TODO 시간 차이 구하기 : System.currentTimeMillis(); 현재 시간을 1/1000초단위로 알려줌
		long start = System.currentTimeMillis();
		
		long sum = 0;
		for(long i=0; i<1000000000L; i++) {
			sum +=i;
		}
		
		long end = System.currentTimeMillis();
		
		System.out.println("걸린 시간: " + ((end-start)/1000));
	}

}
