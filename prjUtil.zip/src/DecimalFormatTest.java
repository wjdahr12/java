import java.text.DecimalFormat;

public class DecimalFormatTest {

	public static void main(String[] args) {
		// TODO java.text.DecimalFormat
		
		double d1 = 2.523, d2 = 3.123;
		
		double result = d1 + d2;
		System.out.println(result);
		
		DecimalFormat df = new DecimalFormat("#.##"); // 소수점 두자리까지만 표기하겠다;
//		System.out.println(df.format(result));
//		두자리까지 자동 반올림;
		
		String strResult = df.format(result);
		System.out.println(strResult.getClass().getSimpleName());
//		타입 확인;
		
//		double d = (double)strResult;
//		기본 타입이기에 캐스팅 불가
		double d = Double.parseDouble(strResult);
//		더블로 바꿔주는 문법
//		wrapper클래스: 기본 데이터 타입을 객체로 다루어야 하는 상황에서 사용
//		여기선 형변환하는데 사용
		System.out.println(d);
		

	}

}
