class EmpManager {
	String name;
	public int no;
	private double pay;
//	private는 무조건 막는것이 아니라 사용할 수 있게 해줘야함
//	그방법이 setter와 getter임
	
	
	void setPay(double pay) {
		this.pay = pay;
//		멀리서 붙일 때에는 public 사용할 것
	}
	
	double getPay() {
		return pay;
//		조회할 수 있게 해줌
	}
}


 

public class AccessModifierTest {

	public static void main(String[] args) {
		// TODO 접근 제한자 연습
		
		EmpManager hong = new EmpManager();
		hong.name = "홍길동";
//		hong = 클래스의 인스턴스로 생성된 객체
		hong.no = 123;
//		hong.pay = 12.2; //private 접근 불가
		hong.setPay(1000000);
//		private걸렸을 때의 사용법
		
		
		System.out.println(hong.name+", "+ hong.no + ", "
				+ hong.getPay());

	}

}
