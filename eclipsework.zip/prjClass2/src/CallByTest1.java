//배열을 이용하는 방법
//public class CallByTest1 {
//	void display(int arr[]) {
//		for(int a : arr) {
//			System.out.println(a);
//		}
//	}
//
//	public static void main(String[] args) {
//		// TODO 값과 참조에 의한 전달1
////		int a=4, b=7, c=15, d=80, e=9;
//		int arr[] = {4, 7, 15, 80, 9};
//		
//		CallByTest1 call = new CallByTest1();
//		call.display(arr);
//
//	}
//
//}

// 인스턴스 변수를 이용하는 방법
//	public class CallByTest1 {
//		int a=4, b=7, c=15, d=80, e=9;
//		
//		public void display() {
//			System.out.println(a+", "+b+", "+c+", "+d+", "+e);
//		}
//	
//	public static void main(String[] args) {
//		// TODO 값과 참조에 의한 전달1
//		CallByTest1 call = new CallByTest1();
//		call.display();
//				
//	}
//	
// }

	
	
	class ArgData{
		int i=4;
		double b=3.14;
		char c = '가';
		boolean d = true;
		String s = "홍길동";
	}
	
	
	public class CallByTest1 {
		
		
		public void display(ArgData data) {
			System.out.println(data.i+", "+data.b+", "+data.c+", "+data.d+", "+data.s);
		}	//객체 데이터 꼮 가져오기
	
	public static void main(String[] args) {
		// TODO 값과 참조에 의한 전달1
		ArgData data = new ArgData();
//		객체 생성
		
		CallByTest1 call = new CallByTest1();
		call.display(data);
				
	}

	
	
 }
	
