
public class CallByTest2 {
	
	
	int[] swap(int n1, int n2) {
		int temp = n1;
		n1 = n2;
		n2 = temp;
		int[] nums = {n1,n2};
		return nums;
		
	}

	public static void main(String[] args) {
		// TODO 값과 참조에 의한 전달2
		int num1 = 10, num2 = 15;
		
		
		System.out.println("두 수의 교환");
		CallByTest2 m2 = new CallByTest2();
		int[] nums = m2.swap(num1, num2);
		//void swap쪽에 static을 붙여도 호환 가능
		System.out.println("num1="+nums[0] + ", num2=" + nums[1]);

	}

}
