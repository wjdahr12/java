abstract class TwoDShape {
	private double width;
	private double height;
	private String name;
	
	public TwoDShape(double width, double height, String name) {
		this.width = width;
		this.height = height;
		this.name = name;
		
	}
	
	public double getWidth() {
		return width;
	}
	
	public double getHeight() {
		return height;
	}
	
	public String getName() {
		return name;
	}
	public abstract double getArea();
//	추상메소드: 어차피 자식 태그에서 고쳐질거 부모태그에서는 그냥 선언만 되어있도록 하는 것;
	
}

class Triangle extends TwoDShape {
	Triangle(double w, double h, String n) {
		super(w, h, n);
	}
	
	@Override
//	문법 틀렸을 때 실수 방지용; @-> 어노테이션;
	public double getArea() {
		return getWidth() * getHeight()/2;
	}
}

class Rectangle extends TwoDShape {
	Rectangle(double w, double h, String n) {
		super(w, h, n);
	}
	
	@Override
	public double getArea() {
		return getWidth() * getHeight();
	}
}

public class ShapeTest {

	public static void main(String[] args) {
		// TODO 2차원 도형을 그리기 위한 프로그램
		Triangle tr1 = new Triangle(5.0, 5.0, "정삼각형");
		Triangle tr2 = new Triangle(7.0, 15.0, "직각삼각형");
		Rectangle re1 = new Rectangle(3.0, 3.0, "정사각형");
		Rectangle re2 = new Rectangle(3.0, 6.0, "직사각형");
//		TwoDShape ts1 = new TwoDShape(5.0, 5.0, "2차원 도형");
//		추상 클래스라 인스턴스 생성불가
		
//		System.out.println(tr1.getName()+ ":"+ tr1.getArea());
//		System.out.println(re1.getName()+ ":"+ re1.getArea());
		
		TwoDShape[] t = {tr1, tr2, re1, re2,
				new Rectangle(3.0,4.0,"그냥 사각형")};
//		부모 클래스이기에 저 다른 클래스들을 하나로 묶을 수 있음
		
		for(int i = 0; i < t.length; i++) {
			System.out.println(t[i].getName()+":"+t[i].getArea());
		}
		

	}

}
