// TODO 상속을 위한 고객관리 프로그램 샘플
public class Cms {
	 private int no;
	 String name;
	 private char level;

	public Cms(int no, String name, char level) {
		this.no = no;
		this.name = name;
		this.level = level;
	}
	
	Cms(){}
//	기본 생성자의 자동 생성 방지
//	객체 생성의 편의성: 인스턴츠 변수의 초기값을 설정하지 않고도 객체 생성 가능
	int getNo() {
		return no;
	}
	
	public void setNo(int no) {
		this.no = no;
	}
	
	String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	char getLevel() {
		return level;
	}
	
	public void setLevel(char level) {
		this.level = level;
	}
	void display() {
		System.out.println("고객 번호:" + no);
		System.out.println("고객 이름:" + name);
		System.out.println("고객 등급:" + level);
	}


}
