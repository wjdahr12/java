// TODO 상속을 위한 고객관리 프로그램 샘플
public class Cms {
	 int no;
	 String name;
	 char level;

	public Cms(int no, String name, char level) {
		this.no = no;
		this.name = name;
		this.level = level;
	}
	
	Cms(){}
//	기본 생성자의 자동 생성 방지
//	객체 생성의 편의성: 인스턴츠 변수의 초기값을 설정하지 않고도 객체 생성 가능
	void display() {
		System.out.println("고객 번호:" + no);
		System.out.println("고객 이름:" + name);
		System.out.println("고객 등급:" + level);
	}


}
