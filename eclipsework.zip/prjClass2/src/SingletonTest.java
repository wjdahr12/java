class SingletonDemo {
	private int i;
	
	private SingletonDemo() {
		// 메인메소드 내에서 인스턴스 생성 못만들게 함.		
	}
	private static SingletonDemo instance = new SingletonDemo();
 //	static으로 유일하게 하나의 객체로 사용할 수 있도록 해줌
	
	public static SingletonDemo getInstance() {
		return instance;
	}
}

public class SingletonTest {

	public static void main(String[] args) {
		// TODO Singleton Pattern
//		SingletonDemo demo1 = new SingletonDemo();
//		SingletonDemo demo2 = new SingletonDemo();
		
		SingletonDemo demo1 = SingletonDemo.getInstance();
		SingletonDemo demo2 = SingletonDemo.getInstance();
//		singleton-> 똑같은 주소로 사용
		System.out.println(demo1.equals(demo2));
//		equals로 주소비교

	}

}
