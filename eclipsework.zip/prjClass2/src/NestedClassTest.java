
public class NestedClassTest {

	public static void main(String[] args) {
//		// TODO 중첩 클래스 활용 테스트
//		
//		// 내부클래스가 static일 경우
//		OuterClass.InnerClass ic = new OuterClass().new InnerClass();
//		ic.innerMethod();
//		ic.inner1 = 100;
//		outerclass에 inner1은 private을 걸어놔서 사용 불가

		
//		내부 클래스가 General일 경우
		OuterClass.InnerClass ic = new OuterClass().new InnerClass();
		ic.innerMethod();
		
	}

}