class A{
	A() {
		System.out.println("A생성자 호출됨");
	}
}

class B extends A{
	B(int i) {
		System.out.println("B생성자 호출됨");
	}
	B() {}
}

class C extends B{
	C() {
//		super(); 원래 호출 된 것 부모가 항상 첫번째로 생성됨; 단지 생략되서 안보인 것
		System.out.println("C생성자 호출됨");
	}
}


public class ConstructorOrderTest {

	public static void main(String[] args) {
		// TODO 생성자 호출 순서
		 new C();

	}

}
