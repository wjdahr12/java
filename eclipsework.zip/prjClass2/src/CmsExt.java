
public class CmsExt extends Cms {
	private String address;

	public CmsExt(int no, String name, char level, String address) {
		this.no = no;
		this.name = name;
		this.level = level;
		this.address = address;
//		내가 선언한 것은 address밖에 없는데 상속받았기에 전부 나타남
		
	}
	
	void print() {
		display();
		System.out.println("고객 주소: " + address);
	}
	
	
}
