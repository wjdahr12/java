
public class CmsExt extends Cms {
//				자식			부모
//				sub			super
	private String address;
//	String name;
//	변수 선언을 통해 자식과 부모간의 데이터 개별 생성

	public CmsExt(int no, String name, char level, String address) {
//		this.no = no;
//		this.name = name;
//		this.level = level;
		
//		setNo(no);
//		setName(name);
//		setLevel(level);
//		부모클래스 setter에 일치할 인수 추가
		
		super(no, name, level);
//		this.name =  "자식";
		this.address = address;
//		내가 선언한 것은 address밖에 없는데 상속받았기에 전부 나타남
		
	}
	

//	void print() {
//		display();
//		System.out.println("고객 주소: " + address);
//		System.out.println("고객 이름: " + this.name);
//	}
	void display() {
//		부모가 물려준 모양 그대로 가져와서 다시 선언해야함:오버라이딩
//		System.out.println("고객 번호:" + getNo());
//		System.out.println("고객 이름:" + name);
//		System.out.println("고객 등급:" + getLevel());
		super.display();
//		super을 통해 부모의 display()가져오기
		System.out.println("고객 주소:" + address);
	}
	
	
}
