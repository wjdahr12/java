
// 내부클래스가 static클래스일 
//public class OuterClass {
//	private int outer1;
////	static 사용으로 outer1사용가능
//	
//	static class InnerClass {
//		private int inner1;
//		
//		void innerMethod() {
//			System.out.println("innerMethod() 호출됨");
//			
//			OuterClass oc = new OuterClass();
//			oc.outer1 = 200;
//			System.out.println(oc.outer1);
//			
////			outer1 = 200;
////			System.out.println(outer1);
////			static이 있어서 호환가능
//		}
//	}
//
//	public static void main(String[] args) {
//		// TODO 중첩 클래스
//		InnerClass ic = new InnerClass();
//		ic.innerMethod();
//		ic.inner1 = 100;
//		System.out.println(ic.inner1);
//
//	}
//
//}

// 내부 클래스가 일반 클래스일 경우
public class OuterClass {
	private int outer1;
	
	 class InnerClass {
		private int inner1;
		
		void innerMethod() {
			System.out.println("innerMethod() 호출됨");
			
			OuterClass oc = new OuterClass();
			oc.outer1 = 200;
			System.out.println(oc.outer1);
			
			outer1 = 200;
			System.out.println(outer1);

		}
	}

	public static void main(String[] args) {
		// TODO 중첩 클래스
		OuterClass oc = new OuterClass();
//		여기서 oc객체를 만들어줘야 innerclass에 oc.붙여서 호환가능
		InnerClass ic = new OuterClass().new InnerClass();
//		InnerClass ic = oc.new InnerClass();
//		둘이 같은 뜻

		ic.innerMethod();
		ic.inner1 = 100;
		System.out.println(ic.inner1);

	}

}










