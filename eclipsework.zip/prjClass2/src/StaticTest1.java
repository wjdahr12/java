 class StaticDemo1 {
//	 메인메소드에 호환시키려면 클래스 객체를 본체에 생성시켜야댐
//	 StaticDemo1 demo1 = new StaticDemo1(); 요렇게
	int a;
	int b;
	static int c;
}

public class StaticTest1 {
	static int d;
	
	static void method1() {
		System.out.println("I'm method~");
	}

	public static void main(String[] args) {
		// TODO Static이란 무엇인지
		StaticDemo1.c = 100;
		System.out.println(StaticDemo1.c);
		
		StaticDemo1 demo1 = new StaticDemo1();
		StaticDemo1 demo2 = new StaticDemo1();
		System.out.println(demo1.c);
		System.out.println(demo2.c);
		
		demo1.c = 200;
		System.out.println(StaticDemo1.c);
		System.out.println(demo2.c);
		
		d= 300;
//		같은 클래스에서 static 사용하는 것은 어느정도 융통성 발휘 가능; 그냥 d라고만 써도 호환
		method1();
		

	}

}
