class First {
	int a = 10;
	

	void display() {
		System.out.println("a: " + a);
	}
}

class Second extends First {
	int b = 20;
	
	void show() {
		System.out.println("b: " + b);
	}
}

public class ReferenceTest {

	public static void main(String[] args) {
		// TODO 부모 클래스와 자식 클래스의 참조 관계
		First f1 = new First();
		f1.display();
		
		Second s1 = new Second();
		s1.show();
		
		First f2 = f1;
		f2.display();
		
//		f2 = s1; 서로 다른 클래스는 절대로 참조x
		f2 = s1;//상속받으면 이야기가 달라짐
		
		
//		Second s2 = (Second)f1; 자식은 부모클래스르 참조할 수 없음
		
		f2.a = 30;
		f2.display();
		
//		f2.b = 40; 자식이 새로 만든 것이라 부모가 참조할 수 없음.
		
		Second s3 = (Second) f2; //f2 = s1; 이쪽에 주소를 받아놔서 f2 호환 가능/ f1은 호환 안됨 주소없어서
		s3.display();
		
		s3.b = 40;
		s3.show();
		
		

	}

}
