package work03;
//인자전달방식
public class MethodTest2 {
	int num1 = 10, num2 = 15;
	
	void swap(MethodTest2 m) {
		int temp = m.num1;
		m.num1 =m.num2;
		m.num2 = temp;
//		둘중하나가 먼저 실행되면 기존값 변질; 절대 두 수로는 교환 불가
//		변수 미리 또다른 변수로 저장해서 num2에 써먹으면 두 수 교환 가능
		System.out.println("num1="+ m.num1 + ", num2=" +m.num2);
	}

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		
		System.out.println("두 수의 교환");
		MethodTest2 m2 = new MethodTest2();
		m2.swap(m2);
		//void swap쪽에 static을 붙여도 호환 가능
		
//		System.out.println("num1="+ m2.num1 + ", num2=" + m2.num2);
	}

}
