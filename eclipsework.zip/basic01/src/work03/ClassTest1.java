package work03;

class ClassDemo{
	int m_no;
	double m_point;
}

public class ClassTest1 {
	int m_ival ;
	double m_dval;
//	class에 있는 전역변수
//	클래스는 선언만 하는 곳 문법 사용x
	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
//		m_ival = 10;
		ClassTest1 i = new ClassTest1();
		i.m_ival = 10;
		System.out.println(i.m_ival);
		
		System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
		
		ClassDemo j = new ClassDemo();
		j.m_no = 100;
		j.m_point = 3.14;
		System.out.println(j.m_no+", "+j.m_point);

	}

}
