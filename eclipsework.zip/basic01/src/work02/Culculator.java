package work02;

import java.util.Scanner;

public class Culculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("연산자: ");
        char operator = scanner.next().charAt(0);

        System.out.print("숫자1: ");
        double number1 = scanner.nextDouble();

        System.out.print("숫자2: ");
        double number2 = scanner.nextDouble();

        double result = 0.0;

        switch (operator) {
            case '+':
                result = number1 + number2;
                break;
            default:
                System.out.println("잘못된 연산자입니다.");
                return;
        }

        System.out.println("결과: " + number1 + " " + operator + " " + number2 + " = " + result);

        scanner.close();
    }
}