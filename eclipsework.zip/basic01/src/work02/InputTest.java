package work02;

import java.io.IOException;

public class InputTest {

	public static void main(String[] args) throws java.io.IOException {
		System.out.println("문자를 입력해주세요: ");
		int input = java.lang.System.in.read();
		System.out.println("입력받은 값:"+ (char)input);
		
		System.in.skip(2);
//		데이터 건너뛰기
		
		System.out.println("숫자를 입력하세요: ");
		input = System.in.read()-48;
		System.out.println("입력받은 값:" + input);

	}

}