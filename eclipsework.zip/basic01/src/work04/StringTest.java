package work04;

public class StringTest {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		String[] names = new String[10];
		names[0] = "Tom";
		names[1] = "Johnson";
		names[2] = "Marry";
		
		System.out.println(names[1]);
		
//		String 클래스 사용법
		
		String str = new String();
		str = "홍길동";
		System.out.println(str);
		
		String str2 = new String("임꺽정");
		System.out.println(str2);
		
		String str3 = "강감찬";
		System.out.println(str3);
		
//		String 클래스 APIs
		String s1 = "java";
//		String s2 = "java";
		String s2 = new String("java");
//		이경우는 항상 새로운 객체를 생성; 값이 같아도 서로 다른 객체를 참조하므로 다르다라고 출력;
		
//		if(s1 ==s2) -> 주소를 봄
//			System.out.println("s1과 s2는 같다.");
//		else
//			System.out.println("s1과 s2는 다르다.");
		
		if(s1.equals(s2)) // 값을 봄; 대소문자까지 전부
			System.out.println("s1과 s2는 같다.");
		else
			System.out.println("s1과 s2는 다르다.");
		
		System.out.println("Java".equalsIgnoreCase(s2));//대소문자 무시
		
		String s3 = "java is beautiful";
		String s4 = "java just one";
		
		System.out.println(s3.compareTo(s4));
//		어느쪽이 큰지 작은지도 비교하는 함수
		System.out.println(s3.charAt(3));
//		4번째 위치에 있는 글자 뽑아오기
		
		System.out.println(s3.indexOf("is"));
//		is가 몇번째에 있는지 숫자체크
		System.out.println(s3.indexOf("a"));
//		왼쪽부터 a값이 어딧는지 알려줌
		System.out.println(s3.lastIndexOf("a"));
//		오른쪽부터 a값이 어딧는지 알려줌
		System.out.println(s3.indexOf("love"));
//		없으면 음수로 나타냄;
		System.out.println(s3.substring(5,6));
//		5시작해서 6번쨰 직전까지의 데이터 가져옴
		System.out.println(s3.substring(5));
//		5번째부터 마지막 데이터까지 전부 출력
		
		String[] sp = s3.split("");
		for(String s : sp) {
			System.out.println(s);
		}
//		s3의 공백을 기준으로 데이터를 출력해줌
		
//		for (int i = 0; i<3; i++ ) {
//			System.out.println(sp[i]);
//		}
		
//		불변성
		String s5 = "javu";
		s5 = "java";
		System.out.println(s5);
		
		String s6 = s5.concat(" is number one");
//		s5와 연결해서 출력해줌
		System.out.println(s6);
		System.out.println(s5 == s6);
//		주소가 다름, 수정 불가
		
		StringBuffer s7 = new StringBuffer("java");
		StringBuffer s8 = s7.append(" is number one");
		System.out.println(s7 == s8);
//		StringBuffer-> String  수정 가능
		
		
		
		
		
		
		
		
		
		
		
	}
	

		
  }




