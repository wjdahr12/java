package work04;

public class BubbleSort {

	public static void main(String[] args) {
		// 버블 정렬 코드; 이진 검색
		int[] data = {
				2, 9, 10, 3, 7, 15, 5
		};
		int pass = 1;
		
		for (int i=0; i<data.length; i++) {
			System.out.println(data[i] + "\t");}
//			\t-> 수평탭, 수평정렬;
			
			System.out.println("\n\n버블정렬 후...");
			
			for(int i=0; i<data.length-1; i++) {
				for(int j=0; j<data.length-pass; j++) {
					if(data[j] > data[j+1]) {
						int temp = data[j];
						data [j] = data[j+1];
						data [j+1] = temp;
					}
				}
				pass++;
			}
		
			for (int i =0; i<data.length; i++) {
				System.out.println(data[i] +"\t");
			}
	}

}
