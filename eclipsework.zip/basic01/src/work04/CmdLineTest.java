package work04;

public class CmdLineTest {

	public static void main(String[] args) {
//		System.out.println(args[0] + ", " + args[1]);
		
		for(int i=0; i<args.length; i++) {
			System.out.println(args[i]);
		}

	}

}
