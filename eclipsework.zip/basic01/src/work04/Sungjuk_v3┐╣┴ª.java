package work04;
// 클래스를 이용한 성적표
class Student {
	String name;
	int no;
	int kor;
	int eng;
	int tot;
	int avg;
	String rank;
	char grade;
	
	Student(String name, int no, int kor, int eng) {
		this.name = name;
		this.no = no;
		this.kor = kor;
		this.eng = eng;
	}
	
}

public class Sungjuk_v3예제 {

	public static void main(String[] args) {
		Student[] st = new Student[3];
//		객체의 주소를 저장할 수 있는 참조변수 3개일 뿐임
		st[0] = new Student("홍길동", 1, 98, 90);
		st[1] = new Student("임꺽정", 2, 76, 55);
		st[2] = new Student("신돌석", 3, 85, 73);
		
//		String[] names = {"홍길동", "임꺽정", "신돌석"};
//		char[] grade = new char[3];
//		int[][] sungjuk = {
//				{1,98,90,0,0,0}, // no, kor, eng, tot, avg, rank
//				{2,76,55,0,0,0},
//				{3,85,73,0,0,0}
//		};
		
		// 총점 구하기
		for (int i=0; i<st.length; i++) {
			st[i].tot = st[i].kor + st[i].eng;
		}
		
		// 평균 구하기
		for (int i=0; i<st.length; i++) {
			st[i].avg = st[i].tot/2;
		}
		
		// 학점 구하기
		for (int i=0; i<st.length; i++) {
			if(st[i].avg>=90)
				st[i].grade = 'A';
			else if
			(st[i].avg>=80)
				st[i].grade = 'B';
			else if
			(st[i].avg>=70)
				st[i].grade = 'C';
			else if
			(st[i].avg>=60)
				st[i].grade = 'D';
			else
				st[i].grade = 'F';
		}
		// 등수 구하기
				for (int i = 0; i < st.length; i++) {
				    int count = 1;
				    for (int j = 0; j < st.length; j++) {
				        if (st[i].avg < st[j].avg) {
				            count++;
				        }
				    }
				    st[i].rank = count + "등";
				}
		
		// 출력		
		System.out.println("***성적 결과***");
		System.out.println("학번\t이름\t국어\t영어\t총점\t평균\t학점\t등수");
		System.out.println("---------------------------------------------------");
//		for(int i=0; i<st.length; i++) {
//			System.out.println(st[i].no + "\t"+ st[i].name+ "\t" + st[i].kor + "\t"
//				+ st[i].eng + "\t" + st[i].tot + "\t" +
//				st[i].avg + "\t" + st[i].grade);
//		}
		
		// 정렬 후 출력
		//선택 정렬
		for(int row=0; row<st.length-1; row++) {
			// 배열을 안쓰고 st이라고만 쓰면 행을 가리켜서 3개로 인식;
			for(int col=row+1; col<st.length; col++) {
				if(st[row].avg < st[col].avg) {
					Student Temp = st[row];
					st[row] = st[col];
					st[col] = Temp;
					
				}
			}// for(col) 종료
		} // for(row) 종료
		for(int i=0; i<st.length; i++) {
			System.out.println(st[i].no + "\t"+ st[i].name+ "\t" + st[i].kor + "\t"
				+ st[i].eng + "\t" + st[i].tot + "\t" +
				st[i].avg + "\t" + st[i].grade + "\t" +st[i].rank);
		}

	}

}