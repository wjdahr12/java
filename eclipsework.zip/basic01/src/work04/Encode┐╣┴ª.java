package work04;

public class Encode예제 {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁
		String msg = "x맨은 홍길동이다.";
		String key = "axdk?!";
		String enc = "", dec = "";
		
		// 메시지를 암호화한 값
		int cnt = 0;
		for(int i = 0; i<msg.length(); i++) {
			enc += (char)(msg.charAt(i)^key.charAt(cnt));
			cnt++;
			if(cnt == key.length()) {
				cnt = 0;
			}
		}
		System.out.println("암호화된 값: "+ enc);
		
		
		
		// 암호화된 메시지를 복호화
		cnt = 0;
		for(int i = 0; i<enc.length(); i++) {
			dec += (char)(enc.charAt(i)^key.charAt(cnt));
			cnt++;
			if(cnt == key.length()) {
				cnt = 0;
			}
		}
			System.out.println("복호화된 값: " + dec);
	}

}
