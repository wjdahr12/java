/**
 * 
 */
/**
 * 
 */
module basic01 {
}