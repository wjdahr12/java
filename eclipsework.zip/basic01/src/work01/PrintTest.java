package work01;

public class PrintTest {

	public static void main(String[] args) {
		System.out.println("안녕하세요");
		System.out.println(10+3);

	}

}
