package work01;

public class OpTest {

	public static void main(String[] args) {
		int a = 10, b= 7;
		
		System.out.println(a>5 && b<3);
		
		System.out.println(a>5 & b<3);
		System.out.println(a & b);
		
		System.out.println(a<9 && ++b>5);
//		단락회로 기능
//		앞의 것이 거짓이면 뒤에 것은 조건을 평가하지 않음		
		System.out.println("b:" + b);
		System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
	
//	          형 변환 연산자
		double d1=3.5, d2=2.3;
		
		int c = (int)d1 + (int)d2;
		System.out.println(c);
		
		double d3 = c;
//		실수형이라 5.0으로 표기됨
		System.out.println("d3:"+ d3);
		
		byte b1 = (byte)c;
		System.out.println("b1:"+ b1);
		
		b1 = 100 +5;
		System.out.println("b1:"+ b1);
		
//		b1 = b1 + 5;
//		현재 b1은 byte여서 int인 5랑 더할 수 없음
//		숫자에는 형변환불가
		b1 = (byte) (b1 + 5);
		System.out.println("b1:"+ b1);
		
		b1 += 5; // b1 = b1 + 5
//		+= 자동 형변환 시켜줌; 자바에서는 가급적 묶어서 연산할 것
		System.out.println("b1:"+ b1);
		
		float f1 = 3.14f;
//		숫자 뒤에 변수 첫글자 쓰면 데이터 형변환
		System.out.println("f1:"+ f1);
		
//		f1 = f1 +2.5f
		f1 += 2.5;
		System.out.println("f1:"+ f1);
		
		int i = 'a';
//		ASCII코드 때문에 값이 97로 나옴
		System.out.println("i:"+ i);
		
		char c1 = 98;
//		ASCII -> b:98;
		System.out.println("c1:"+ c1);

		long x = 100000000000L;

	}

}