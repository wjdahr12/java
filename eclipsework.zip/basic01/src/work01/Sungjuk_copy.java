package work01;

 class Student {
    String name;
    int no;
    int kor;
    int eng;
    int tot;
    int avg;
    String rank;
    char grade;

    Student(String name, int no, int kor, int eng) {
        this.name = name;
        this.no = no;
        this.kor = kor;
        this.eng = eng;
        this.tot = kor + eng;
        this.avg = tot / 2;
    }

    char calculateGrade() {
        if (avg >= 90) return 'A';
        else if (avg >= 80) return 'B';
        else if (avg >= 70) return 'C';
        else if (avg >= 60) return 'D';
        else return 'F';
    }
    
    String calculateRanks(Student[] students) {
    	for (int i = 0; i < students.length; i++) {
 		    int count = 1;
 		    for (int j = 0; j < students.length; j++) {
 		        if (students[i].avg < students[j].avg) {
 		            count++;
 		        }
 		    }
 		   students[i].rank = count + "등";
 		  
 		}
		return rank;
		
    }
}

public class Sungjuk_copy {
    public static void main(String[] args) {
        Student[] students = new Student[3];

        students[0] = new Student("홍길동", 1, 98, 90);
        students[1] = new Student("임꺽정", 2, 76, 55);
        students[2] = new Student("신돌석", 3, 85, 73);
        
        
     // 등수 구하기
//     		for (int i = 0; i < students.length; i++) {
//     		    int count = 1;
//     		    for (int j = 0; j < students.length; j++) {
//     		        if (students[i].avg < students[j].avg) {
//     		            count++;
//     		        }
//     		    }
//     		   students[i].rank = count + "등";
//     		}

        // 정렬 (평균 내림차순)
        for (int i = 0; i < students.length - 1; i++) {
            for (int j = i + 1; j < students.length; j++) {
                if (students[i].avg < students[j].avg) {
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }

        System.out.println("***성적 결과***");
        System.out.println("학번\t이름\t국어\t영어\t총점\t평균\t학점\t등수");
        System.out.println("---------------------------------------------------");
        for (Student student : students) {
            System.out.println(
                    student.no + "\t" + student.name + "\t" + student.kor + "\t" +
                    student.eng + "\t" + student.tot + "\t" +
                    student.avg + "\t" + student.calculateGrade() + "\t"
                    + student.calculateRanks(students)
            );
        }
    }
}
