
public class ExcDemo3 {

	public static void main(String[] args) {
		int[] arr = new int[3];
		
		System.out.println("Exception 실행 예제...");
		try {
		arr[7] = 10;
		//...
//		double d = 10/0;
		} 
		catch(Exception err) {
			System.out.println("오류 발생" + err);
			return;
//			리턴 사용으로 에러 발생시 거기서 끊어버림
//			System.exit(0);
//			이부분에서 아예 다 종료시켜버림; 가급적 쓰면 안되는 명령어
		}
		finally {
			System.out.println("이곳은 반드시 실행되는 영역이다.");
		} // 에러가 나든 안나든 무조건 실행 코드
		
		System.out.println("이 문장이 보이는가?");

	}

}
