
public class ExcDemo4 {

	public static void main(String[] args) {
		try {
			System.out.println("여기는 try블럭 내부이다.");
			throw new RuntimeException("이것은 테스트용이다.");
//			일부로 예외를 발생시키는 코드
			
		}
		catch(RuntimeException err) {
			System.out.println("예외 처리됨...: " + err.getMessage());
//			RuntimeException();의 내용을 받을 수 있게 해주는 코드; getMessage();
		}

	}

}
