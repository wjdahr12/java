import java.io.IOException;

public class ExcDemo5 {
	static void second() throws IOException, ArithmeticException {
//		책임전가
		System.out.println("second 호출됨");
		
		int i = System.in.read();
		int j = i/3;
		throw new ArrayIndexOutOfBoundsException();
		}
	
	static void first() throws IOException, ArithmeticException {
//		책임전가
		System.out.println("first 호출됨");
		second();
	}
	public static void main(String[] args) {
		try {
			first();
		} catch (Exception e) {
			// TODO 자동 생성된 catch 블록
			System.out.println("main에서 다 처리함...");
//			int 입력시 전부 예외로 던져져서 main까지 흘러들어옴;
//			ArithmeticException 포함으로 던져서 catch구문 활성화
			e.printStackTrace();
//			예외 처리 후 디버깅 메소드
//			예외가 발생한 위치 표시
		}

	}

}
