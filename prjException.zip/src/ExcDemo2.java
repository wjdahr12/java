import java.io.IOException;

//		try catch로 예외 처리
//public class ExDemo2 {
//
//	public static void main(String[] args) {
//		System.out.println("문자를 입력해주세요: ");
//		int input = 0;
//		try {
//			input = java.lang.System.in.read();
//			System.out.println("입력받은 값:"+ (char)input);
//		} catch (IOException err) {
//			// TODO 자동 생성된 catch 블록
//			System.out.println("입력 오류: " + err);
//		}
//		
//
//	}
//
//}


//      throws로 간단하게 예외 선언
public class ExcDemo2 {

	public static void main(String[] args) throws IOException {
		System.out.println("문자를 입력해주세요: ");
		
		
		int input = java.lang.System.in.read();
		System.out.println("입력받은 값:"+ (char)input);
		
		

	}

}
