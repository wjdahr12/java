import java.io.File;
import java.time.Instant;

public class FileTest {

	public static void main(String[] args) {
		// TODO File 클래스
		File f = new File("C:\\wjdahr12\\Java\\eclipsework\\emp.dat");
		
		if(f.exists()) {
			System.out.println("파일의 이름 : " + f.getName());
			System.out.println("상대 경로 : " + f.getPath());
			System.out.println("절대 경로 : " + f.getAbsolutePath());
			System.out.println("크기 : " + f.length() + "byte");
			
			Instant lastModifiedInstant = Instant.ofEpochMilli(f.lastModified());
			System.out.println("마지막 수정일자 : " + lastModifiedInstant);
		}
		else {
			System.out.println("파일이 존재하지 않습니다.");
		}
		f.delete();

	}

}
