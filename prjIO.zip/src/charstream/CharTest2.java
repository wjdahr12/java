package charstream;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

//public class CharTest2 {
//	static void StreamTest(InputStream in) throws IOException {
//		InputStreamReader isr = new InputStreamReader(in);
////		문자스트림으로 바꿔주는 객체 클래스 생성 매개변수로 (in)
//		
//	 	int input = isr.read();
////	 	in대신 isr로 변경해야 한글패치 가능
//	 	
//	 	while(input != -1) {
////	 		여기서 -1이란 ctrl+z를 정의함
////	 		직접 -1입력하면 키보드 2개를 입력해서 작동 x
//	 		System.out.print((char)input);
//	 		input = isr.read();
////		 	in대신 isr로 변경해야 한글패치 가능
//	 	}
//		
//		
//		
//	}
//
//	public static void main(String[] args) throws IOException {
//		// TODO 자동 생성된 메소드 스텁
//		StreamTest(System.in);
//
//	}
//
//}


public class CharTest2 {
	static void StreamTest(InputStream in) throws IOException {
		InputStreamReader isr = new InputStreamReader(in);
//		문자스트림으로 바꿔주는 객체 클래스 생성 매개변수로 (in)
		BufferedReader br = new BufferedReader(isr);
//		보조스트림
		
	 	String input = br.readLine();
//	 	isr.read();에서 이제는 한줄씩 읽기 때문에 readLine();으로 바꿔줌
	 	
	 	while(input != null) {
//	 		-1은 한글자, null은 마지막줄 더이상 읽어올게 없을 때 종료
	 		System.out.print(input);
	 		input = br.readLine();

	 	}
		
		isr.close();
		br.close();
		
	}

	public static void main(String[] args) throws IOException {
		// TODO 자동 생성된 메소드 스텁
		StreamTest(System.in);

	}

}
