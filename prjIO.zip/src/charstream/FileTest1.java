package charstream;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class FileTest1 {

	public static void main(String[] args) {
		// TODO 파일로부터 입력받아 콘솔로 출력
		BufferedReader br = null;
		try {
		      br =
				new BufferedReader(new FileReader("C:\\wjdahr12\\Java\\eclipsework\\test.txt"));
//						역슬레시 2개인 이유: \n 등 특수문자로 사용될 수 있기 때문
		
		
		String input = null;
		while((input = br.readLine()) != null) {
			System.out.println(input);
			
			
//			txt에서 enter를 누르든 안누르든 화면에 다읽어서 출력해주는 메소드
		}

		}
		catch(FileNotFoundException e) {
			System.out.println("파일을 찾을 수 없다. : "+ e);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
