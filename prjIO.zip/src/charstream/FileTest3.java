package charstream;

import java.io.IOException;
import java.io.PrintWriter;

public class FileTest3 {

	public static void main(String[] args) throws IOException {
		// TODO PrintWriter 예제
//		FileWriter fout = new FileWriter("C:\\wjdahr12\\Java\\eclipsework\\test3.txt");
		
		PrintWriter fout = new PrintWriter("C:\\wjdahr12\\Java\\eclipsework\\test3.txt");
//		FileWriter보다 PrintWriter가 내부적으로는 성능개선이 뛰어남; 버퍼를 더 크게 쓰기 때문
		
		for(int i=0; i<10; i++) {
			String data = i + "번째 줄입니다.\r\n";
//			fout.write(data);
			fout.println(data);
		}
			
		fout.close();
	}

}
