package charstream;

import java.io.IOException;
import java.io.PrintWriter;

public class FileTest4 {

	public static void main(String[] args) throws IOException {
		// TODO PrintWriter 예제2
//		 PrintWriter pw = new PrintWriter(new BufferedWriter(
//		new FileWriter("C:\\wjdahr12\\Java\\eclipsework\\sungjuk.txt")));
//		 3가지 전부 래핑 때려버림
		 
		 PrintWriter pw = new PrintWriter("C:\\wjdahr12\\Java\\eclipsework\\sungjuk.txt");
//		위 3가지 래핑을 PrintWriter로 한번에 해결 가능; 출력에 특화된 기능
		 
		 pw.println("***************** 성적표 **********************");
		 pw.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
		 pw.printf("%3s : %5d %5d %5.1f %n",
				 	"홍길동", 97, 67, (float)((98+67)/2));
		 pw.printf("%3s : %5d %5d %5.1f %n",
				 	"임꺽정", 64, 61, (float)((64+61)/2));
		 pw.printf("%3s : %5d %5d %5.1f %n",
				 	"신돌석", 78, 60, (float)((78+60)/2));
		 
		 pw.close();

	}

}
	
/*
	%3s: 문자열을 출력하는데 최소 3자리를 사용하라는 의미
	%5d: 정수를 출력하는데 최소 5자리를 사용하라는 의미
	5.1f: 부동 소수점 숫자를 출력하는데 소수점 아래 1자리를 포함하여 총 5자리를 사용하라는 의미
	%n: 줄 바꿈 문자를 삽입
*/