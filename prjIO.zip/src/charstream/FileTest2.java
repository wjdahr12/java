//package charstream;
//
//import java.io.BufferedWriter;
//import java.io.FileOutputStream;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.Reader;
//import java.util.Scanner;
//
//public class FileTest2 {
//
//	public static void main(String[] args) throws IOException {
//		// TODO 키보드로부터 입력받아 파일로 출력
//		BufferedWriter bw =
//		new BufferedWriter(new FileWriter("C:\\wjdahr12\\Java\\eclipsework\\test3.txt"));
//		
//		 Scanner scanner = new Scanner(System.in);
//		
//		String input = null;
//		while(scanner.hasNext()) {
//			input = scanner.nextLine();
//			
//			if(input == null) 
//				break;
//			
//			bw.write(input);
//			bw.newLine();
//			bw.flush();
//			
//		}
//		bw.close();
//		scanner.close();
//
//	}
//
//}


/*
 java Jcopy a.txt b.txt
 
 java Jcomp a.txt b.txt 만들기
*/


package charstream;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileTest2 {

	public static void main(String[] args) throws IOException {
		// TODO 키보드로부터 입력받아 파일로 출력
		PrintWriter bw =
		new PrintWriter(new FileWriter("C:\\wjdahr12\\Java\\eclipsework\\test3.txt"));
		
		 Scanner scanner = new Scanner(System.in);
		
		String input = null;
		while(scanner.hasNext()) {
			input = scanner.nextLine();
			
			 if (input == null)
				break;
			
			bw.write(input);
//			bw.newLine();
			bw.flush();
			
		}
		bw.close();
		scanner.close();

	}

}
