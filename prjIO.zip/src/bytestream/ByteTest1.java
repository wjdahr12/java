package bytestream;

import java.io.IOException;

public class ByteTest1 {

	public static void main(String[] args) throws IOException {
		byte[] data = new byte[10];
		
		System.out.println("문자열 입력: ");
		System.in.read(data);
//		변수 입력하면 10글자를 키보드로 입력 가능
//		read() 아무것도 없으면 key 하나만 입력 가능
		
		System.out.println("당신이 입력한 문자를 :");
		for (byte d : data) {
			System.out.print((char)d);
		}
		

	}

}
