package bytestream;

import java.io.Serializable;

public class Employee implements Serializable  {
//								직렬화가 가능하도록 Serializable 인터페이스 구현
	private int no;
	private String name;
	private String job;
	private int deptno;
	private double sal;
	
	
	public Employee(int no, String name, String job, int deptno, double sal) {
		super();
		this.no = no;
		this.name = name;
		this.job = job;
		this.deptno = deptno;
		this.sal = sal;
	}
	@Override
	public String toString() {
		return no + "\t" +name + "\t" +job + "\t" +deptno + "\t" +sal;
		
	}
	
}
