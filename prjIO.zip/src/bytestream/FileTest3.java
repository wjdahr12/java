package bytestream;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileTest3 {

	public static void main(String[] args) throws IOException {
		FileOutputStream fout =
				new FileOutputStream("C:\\wjdahr12\\Java\\eclipsework\\test3.txt", true);
		
		for(int i =1; i<10; i++) {
			String str = i +"번째 줄입니다.\r\n";
//										줄바꿈
			System.out.println(str);
			fout.write(str.getBytes());
//							bytes로 바꿔주는 메소드
			
		}
		fout.close();

	}

}
