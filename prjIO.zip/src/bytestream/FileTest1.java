package bytestream;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;

public class FileTest1 {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// TODO 파일로부터 입력받아 콘솔로 출력
		FileInputStream fin =
		new FileInputStream("C:\\wjdahr12\\Java\\eclipsework\\test.txt");
//						역슬레시 2개인 이유: \n 등 특수문자로 사용될 수 있기 때문
		
		int input = 0;
		while(input != -1) {
//			-1: file의 마지막을 의미함;
			input = fin.read();
//			System.out.write((char)input);
			PrintStream os = System.out;
			os.write((char)input);
			os.flush();
//			txt에서 enter를 누르든 안누르든 화면에 다읽어서 출력해주는 메소드
		}
		fin.close();
//		끝나면 닫아주는 습관 들이기;

	}

}
