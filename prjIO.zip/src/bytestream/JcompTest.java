package bytestream;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class JcompTest {

	public static void main(String[] args) throws IOException {
		// TODO Jcomp a.txt 와 b.txt이 같은 파일인가 비교
		File file1 = new File("C:\\B8angho\\JavaWork\\test.txt");
		File file2 = new File("C:\\B8angho\\JavaWork\\test4.txt");

		FileInputStream input1 = new FileInputStream(file1);
		FileInputStream input2 = new FileInputStream(file2);

		int input1Data;
		int input2Data;

		boolean filesEqual = true;

		while (true) {
			input1Data = input1.read();
			input2Data = input2.read();

			if (input1Data != input2Data) {
				filesEqual = false;
				break;
			}
			if (input1Data == -1 && input2Data == -1) {
				break;
			}
		}
		if (filesEqual) {
			System.out.println(file1.getName() + "와 " + file2.getName() + "은 같은 내용이다.");
		} else {
			System.out.println(file1.getName() + "와 " + file2.getName() + "은 다른 내용이다.");
		}
		input1.close();
		input2.close();
	}
}