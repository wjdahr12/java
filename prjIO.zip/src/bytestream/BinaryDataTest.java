package bytestream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BinaryDataTest {

	public static void main(String[] args) throws IOException {
		// TODO DataInputStream, DataOutputStream
		FileOutputStream fout =
				new FileOutputStream("C:\\wjdahr12\\Java\\eclipsework\\test4.txt");
		
		DataOutputStream dout =
//				이진수로 바꿔서 저장
				new DataOutputStream(fout);
		dout.writeChar('가');
		dout.writeInt(100);
		dout.writeDouble(3.14);
		dout.writeBoolean(true);
		
		dout.close();
		fout.close();
		
		DataInputStream din =
				new DataInputStream(
						new FileInputStream("C:\\wjdahr12\\Java\\eclipsework\\test4.txt"));
		
		System.out.println(din.readChar());
		System.out.println(din.readInt());	
		System.out.println(din.readDouble());	
		System.out.println(din.readBoolean());
//		차례에 맞게 순서대로 출력
		
		din.close();

	}

}
