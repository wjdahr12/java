package bytestream;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileTest2 {

	public static void main(String[] args) throws IOException {
		// TODO 키보드로부터 입력받아 파일로 출력
		FileOutputStream fout =
		new FileOutputStream("C:\\wjdahr12\\Java\\eclipsework\\test3.txt", true);
//				true에 경우 새로운 데이터를 파일에 끝에 추가
//				false에 경우 기존 파일의 내용을 새로운 데이터로 덮어씀
		
		int input =0;
		while(true) {
			input = System.in.read();
			
			if(input == -1) 
//				-1: ctrl z
				break;
			
			fout.write((char)input);
			fout.flush();
			
		}
		fout.close();

	}

}


/*
 java Jcopy a.txt b.txt
 
 java Jcomp a.txt b.txt 만들기
*/

