package bytestream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ByteTest2 {
	static void StreamTest(InputStream in, OutputStream out) throws IOException {
	 	int input = in.read();
	 	
	 	while(input != -1) {
//	 		여기서 -1이란 ctrl+z를 정의함
//	 		직접 -1입력하면 키보드 2개를 입력해서 작동 x
	 		out.write((char)input);
	 		input = in.read();
	 	}
		
		
		
	}

	public static void main(String[] args) throws IOException {
		// TODO 자동 생성된 메소드 스텁
		StreamTest(System.in, System.out);

	}

}
