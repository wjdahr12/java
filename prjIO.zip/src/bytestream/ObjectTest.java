package bytestream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO 자동 생성된 메소드 스텁
		Employee[] emp = new Employee[3];
		emp[0] = new Employee(1,"홍길동", "영업", 3, 3500);
		emp[1] = new Employee(2,"james", "manager", 2, 2000);
		emp[2] = new Employee(3, "losa", "개발", 1, 3000);
		
		ObjectOutputStream oos = new ObjectOutputStream(
				new FileOutputStream("C:\\wjdahr12\\Java\\eclipsework\\emp.dat"));
//												보통 이진수 저장은 .dat로 확장자 저장
		
		oos.writeObject(emp[0]);
		oos.writeObject(emp[1]);
		oos.writeObject(emp[2]);
		
		oos.close();
		
		System.out.println("*************** 사원 정보 *******************");
		System.out.println("사번\t이름\t업무\t부서\t급여");
		System.out.println("------------------------------------------------");
		
		ObjectInputStream ois = new ObjectInputStream(
				new FileInputStream("C:\\wjdahr12\\Java\\eclipsework\\emp.dat"));
		
		for(int i =0; i<3; i++) {
			Employee e = (Employee)ois.readObject();
//										파일에서 객체를 읽어오는 메소드;
			System.out.println(e);
			
		}
		ois.close();
	}

}
